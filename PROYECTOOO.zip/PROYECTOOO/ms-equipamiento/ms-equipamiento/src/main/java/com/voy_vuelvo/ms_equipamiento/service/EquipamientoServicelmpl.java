package com.voy_vuelvo.ms_equipamiento.service;

import com.voy_vuelvo.ms_equipamiento.model.Equipamiento;
import com.voy_vuelvo.ms_equipamiento.repository.EquipamientoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EquipamientoServicelmpl implements EquipamientoService {

    @Autowired
    private EquipamientoRepository repository;

    @Override
    public List<Equipamiento> findAll() {
        return (List<Equipamiento>) repository.findAll();
    }

    @Override
    public Optional<Equipamiento> findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public Equipamiento save(Equipamiento equipamiento) {
        return repository.save(equipamiento);
    }

    @Override
    public Equipamiento update(Long id, Equipamiento equipamiento) {
        if (repository.existsById(id)) {
            equipamiento.setIdEquipamiento(id);
            return repository.save(equipamiento);
        }
        return null;
    }

    @Override
    public boolean delete(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public List<Equipamiento> findByNombre(String nombre) {
        return repository.findByNombre(nombre);
    }
}