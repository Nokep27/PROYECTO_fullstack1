package com.voy_vuelvo.ms_equipamiento.service;

import com.voy_vuelvo.ms_equipamiento.model.Equipamiento;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface EquipamientoService {

    List<Equipamiento> findAll();

    Optional<Equipamiento> findById(Long id);

    Equipamiento save(Equipamiento equipamiento);

    Equipamiento update(Long id, Equipamiento equipamiento);

    boolean delete(Long id);

    List<Equipamiento> findByNombre(String nombre);
}