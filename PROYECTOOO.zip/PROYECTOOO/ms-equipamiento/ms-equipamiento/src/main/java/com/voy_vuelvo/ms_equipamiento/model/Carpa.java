package com.voy_vuelvo.ms_equipamiento.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "carpas")
@DiscriminatorValue("CARPA")
public class Carpa extends Equipamiento {

    @NotNull
    private Integer capacidadPersonas;

    @NotNull
    private Boolean impermeable;

    @Enumerated(EnumType.STRING)
    @NotNull
    private Estacion estacion;
}
