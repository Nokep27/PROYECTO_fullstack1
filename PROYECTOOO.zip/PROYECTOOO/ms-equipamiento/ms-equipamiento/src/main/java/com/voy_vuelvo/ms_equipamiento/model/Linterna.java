package com.voy_vuelvo.ms_equipamiento.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "linternas")
@DiscriminatorValue("LINTERNA")
public class Linterna extends Equipamiento {


    @NotNull
    private String tipoLuz;

    @NotNull
    private Integer potencia;

    @NotNull
    private Integer duracionBateria;

    @NotNull
    private Boolean recargable;

    @NotNull
    private Boolean resistenteAgua;
}