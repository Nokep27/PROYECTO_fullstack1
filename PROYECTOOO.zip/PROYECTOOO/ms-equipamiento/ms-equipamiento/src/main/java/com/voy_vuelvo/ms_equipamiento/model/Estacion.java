package com.voy_vuelvo.ms_equipamiento.model;


public enum Estacion {
    VERANO,
    INVIERNO,
    TODA_TEMPORADA
}
