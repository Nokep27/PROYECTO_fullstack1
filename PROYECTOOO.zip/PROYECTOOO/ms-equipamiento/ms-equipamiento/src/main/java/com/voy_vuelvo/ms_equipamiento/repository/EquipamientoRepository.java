package com.voy_vuelvo.ms_equipamiento.repository;

import com.voy_vuelvo.ms_equipamiento.model.Equipamiento;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface EquipamientoRepository extends CrudRepository<Equipamiento, Long> {

    List<Equipamiento> findByNombre(String nombre);
    List<Equipamiento> findByEstado(String estado);
    List<Equipamiento> findByObligatorio(boolean obligatorio);



}
