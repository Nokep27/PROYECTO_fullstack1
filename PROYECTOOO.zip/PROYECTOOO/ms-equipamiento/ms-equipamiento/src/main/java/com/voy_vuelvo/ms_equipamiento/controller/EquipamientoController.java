package com.voy_vuelvo.ms_equipamiento.controller;

import com.voy_vuelvo.ms_equipamiento.model.Equipamiento;
import com.voy_vuelvo.ms_equipamiento.service.EquipamientoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/equipamiento")
public class EquipamientoController {

    @Autowired
    private EquipamientoService service;

    // LISTAR
    @GetMapping
    public ResponseEntity<List<Equipamiento>> findAll() {
        return ResponseEntity.ok(service.findAll());
    }

    // BUSCAR
    @GetMapping("/{id}")
    public ResponseEntity<Equipamiento> findById(@PathVariable Long id) {
        return service.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    //GUARDAR
    @PostMapping
    public ResponseEntity<Equipamiento> save(@RequestBody Equipamiento equipamiento) {
        return ResponseEntity.status(201).body(service.save(equipamiento));
    }

    //ACTUALIAR
    @PutMapping("/{id}")
    public ResponseEntity<Equipamiento> update(@PathVariable Long id,
                                               @RequestBody Equipamiento equipamiento) {

        Equipamiento actualizado = service.update(id, equipamiento);

        if (actualizado != null) {
            return ResponseEntity.ok(actualizado);
        }
        return ResponseEntity.notFound().build();
    }

    //ELIMINAR
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (service.delete(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    // BUSCAR POR NOMBRE
    @GetMapping("/nombre/{nombre}")
    public ResponseEntity<List<Equipamiento>> findByNombre(@PathVariable String nombre) {
        return ResponseEntity.ok(service.findByNombre(nombre));
    }
}