package com.voy.velvo.ms_reserva.service;

import com.voy.velvo.ms_reserva.client.PagoClient;
import com.voy.velvo.ms_reserva.model.Reserva;
import com.voy.velvo.ms_reserva.model.Dto.PagoDTO;
import com.voy.velvo.ms_reserva.repository.ReservaRepository;
import jakarta.annotation.Nonnull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReservaService {

    private final ReservaRepository reservaRepository;
    private final PagoClient pagoClient;

    public Reserva crearReserva(Reserva reserva) {

        // 1. Guardamos la reserva inicialmente como PENDIENTE
        reserva.setEstadoPago("PENDIENTE");
        Reserva reservaGuardada = reservaRepository.save(reserva);

        // 2. Armamos el DTO con los nombres EXACTOS que ms-pago pide
        PagoDTO pagoParaEnviar = new PagoDTO();
        pagoParaEnviar.setIdReserva(reservaGuardada.getId());
        pagoParaEnviar.setMonto(5000.0); // Monto fijo por ahora, se puede dinamizar luego
        pagoParaEnviar.setEstado("PENDIENTE");
        pagoParaEnviar.setFechaPago(reservaGuardada.getFechaReserva().toString());

        // 3. Llamamos al microservicio de tu amigo usando Feign enviando el DTO.
        // Spring lo convierte a un JSON que ms-pago sí va a entender perfectamente.
        pagoClient.crearPagoInterno(pagoParaEnviar);

        // 4. Si la línea de arriba funcionó (no dio error), cambiamos el estado.
        reservaGuardada.setEstadoPago("PROCESANDO");
        return reservaRepository.save(reservaGuardada);
    }



    // Metodo para buscar todas las reservas
    public List<Reserva> obtenerTodas() {
        return reservaRepository.findAll();
    }

    // Metodo para buscar UNA sola reserva por su ID
    public Reserva obtenerPorId(Long id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Error: La reserva con ID " + id + " no existe."));
    }

    // Metodo para actualizar una reserva existente
    public Reserva actualizarReserva(Long id, Reserva detallesNuevos) {
        Reserva reservaExistente = obtenerPorId(id);

        // 2. Actualizamos los datos que permitimos cambiar
        reservaExistente.setCantidadPersonas(detallesNuevos.getCantidadPersonas());
        reservaExistente.setFechaReserva(detallesNuevos.getFechaReserva());
        reservaExistente.setNecesitaGuia(detallesNuevos.getNecesitaGuia());
        // No actualizamos el ID ni el usuarioId por seguridad
        return reservaRepository.save(reservaExistente);
    }

    // Metodo para eliminar una reserva
    public void eliminarReserva(Long id) {
        obtenerPorId(id);

        reservaRepository.deleteById(id);
    }
}