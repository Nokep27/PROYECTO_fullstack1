package com.voy.velvo.ms_reserva.repository;

import com.voy.velvo.ms_reserva.model.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
}
