package com.voy.vuelvo.ms_pago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
